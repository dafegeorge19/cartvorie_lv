@extends('layouts.customer')
@section('body-class', 'page-template-default woocommerce-checkout woocommerce-page woocommerce-order-received can-uppercase woocommerce-active')



@section('content')
<br>
<br>

<div id="content" class="site-content">
    <div class="col-full">
        <div class="row">
            <div id="primary" class="content-area">
                <main id="main" class="site-main">
                    <div class="type-page hentry">
                        <header class="text-center">
                            <div class="page-header-caption">
                                <h1 class="entry-title">About Us</h1>
                            </div>
                        </header>
                        <div class="entry-content">
                            <section class="section terms-conditions">
                                <p>We are On-demand  e-commerce platform, we partner  with the most popular and trusted  retailers to deliver their products  making shopping  effortless and time saving for our customers, Be rest assured of the Genuineness of all product on our platform  because we  partner with  trusted retailers that  you’re most probably familiar with, Who would you run to when you realise your  Dinner Gown is torn  an hour before your Date  Or your Charger Blown out when your Phone is 2% in cases as these we have you covered,  Our List of Stores ranges from but  not limited to Pharmacies, Supermarkets, Gift Shops, Boutique, Phones/Accessories  all The way down to Liquor Stores, We deliver just about Anything from any Store in an Hour.</p>
                            </section>
                            <!-- .terms-conditions -->
                        </div>
                        <!-- .entry-content -->
                    </div>
                    <!-- .hentry -->
                </main>
                <!-- #main -->
            </div>
            <!-- #primary -->
        </div>
        <!-- .row -->
    </div>
    <!-- .col-full -->
</div>


@endsection