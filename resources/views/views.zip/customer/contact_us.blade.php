@extends('layouts.customer')
@section('body-class', 'page home page-template-default')



@section('content')
<br>
<br>
            <div id="content" class="site-content">
                <div class="col-full">
                    <div class="row">
                        <!-- .woocommerce-breadcrumb -->
                        <div id="primary" class="content-area">
                            <main id="main" class="site-main">
                                <div class="type-page hentry">
                                    <header class="entry-header">
                                        <div class="page-header-caption">
                                            <h1 class="entry-title">Contact Us</h1>
                                        </div>
                                    </header>
                                    <!-- .entry-header -->
                                    <div class="entry-content">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="text-block">
                                                    <h2 class="contact-page-title">Leave us a Message</h2>
                                                    <p>We will get back to you as soon as possible</p>
                                                </div>
                                                <div class="contact-form">
                                                    <div role="form" class="wpcf7" id="wpcf7-f425-o1" lang="en-US" dir="ltr">
                                                        <div class="screen-reader-response"></div>
                                                        <form class="wpcf7-form" novalidate="novalidate">
                                                            <div style="display: none;">
                                                                <input type="hidden" name="_wpcf7" value="425" />
                                                                <input type="hidden" name="_wpcf7_version" value="4.5.1" />
                                                                <input type="hidden" name="_wpcf7_locale" value="en_US" />
                                                                <input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f425-o1" />
                                                                <input type="hidden" name="_wpnonce" value="e6363d91dd" />
                                                            </div>
                                                            <div class="form-group row">
                                                                <div class="col-xs-12 col-md-6">
                                                                    <label>First name
                                                                        <abbr title="required" class="required">*</abbr>
                                                                    </label>
                                                                    <br>
                                                                    <span class="wpcf7-form-control-wrap first-name">
                                                                        <input type="text" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" size="40" value="" name="first-name">
                                                                    </span>
                                                                </div>
                                                                <!-- .col -->
                                                                <div class="col-xs-12 col-md-6">
                                                                    <label>Last name
                                                                        <abbr title="required" class="required">*</abbr>
                                                                    </label>
                                                                    <br>
                                                                    <span class="wpcf7-form-control-wrap last-name">
                                                                        <input type="text" aria-invalid="false" aria-required="true" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required input-text" size="40" value="" name="last-name">
                                                                    </span>
                                                                </div>
                                                                <!-- .col -->
                                                            </div>
                                                            <!-- .form-group -->
                                                            <div class="form-group">
                                                                <label>Subject</label>
                                                                <br>
                                                                <span class="wpcf7-form-control-wrap subject">
                                                                    <input type="text" aria-invalid="false" class="wpcf7-form-control wpcf7-text input-text" size="40" value="" name="subject">
                                                                </span>
                                                            </div>
                                                            <!-- .form-group -->
                                                            <div class="form-group">
                                                                <label>Your Message</label>
                                                                <br>
                                                                <span class="wpcf7-form-control-wrap your-message">
                                                                    <textarea aria-invalid="false" class="wpcf7-form-control wpcf7-textarea" rows="10" cols="40" name="your-message"></textarea>
                                                                </span>
                                                            </div>
                                                            <!-- .form-group-->
                                                            <div class="form-group clearfix">
                                                                <p>
                                                                    <input type="submit" value="Send Message" class="wpcf7-form-control wpcf7-submit" />
                                                                </p>
                                                            </div>
                                                            <!-- .form-group-->
                                                            <div class="wpcf7-response-output wpcf7-display-none"></div>
                                                        </form>
                                                        <!-- .wpcf7-form -->
                                                    </div>
                                                    <!-- .wpcf7 -->
                                                </div>
                                                <!-- .contact-form7 -->
                                            </div>
                                            <!-- .col -->
                                            <div class="col-md-6 store-info store-info-v2">
                                                <!-- .google-map -->
                                                <div class="kc-elm kc-css-773435 kc_text_block">
                                                    <h2 class="contact-page-title">Our Contacts</h2>
                                                    <p>our address
                                                        <br> Support(+234)our phone
                                                        <br> Email: <a href="mailto:contact@yourstore.com">Our Email here</a>
                                                    </p>
                                                </div>
                                            </div>
                                            <!-- .col -->
                                        </div>
                                        <!-- .row -->
                                    </div>
                                    <!-- .entry-header -->
                                </div>
                                <!-- .hentry -->
                            </main>
                            <!-- #main -->
                        </div>
                        <!-- #primary -->
                    </div>
                    <!-- .row -->
                </div>
                <!-- .col-full -->
            </div>
@endsection